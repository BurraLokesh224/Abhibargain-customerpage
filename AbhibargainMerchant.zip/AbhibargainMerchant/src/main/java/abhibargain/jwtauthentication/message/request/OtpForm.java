package abhibargain.jwtauthentication.message.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class OtpForm {
	
	  @NotNull
	 // @Size(min = 4, max = 4)
	  private int otp;
	  

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

}
