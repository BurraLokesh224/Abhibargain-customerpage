package abhibargain.jwtauthentication.security.services;

import com.fasterxml.jackson.annotation.JsonIgnore;

import abhibargain.jwtauthentication.model.User;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;



public class UserPrinciple implements UserDetails {
	private static final long serialVersionUID = 1L;

	private Long id;

    private String firstname;
    
    private String lastname;

    private String username;

    private String email;

    @JsonIgnore
    private String password;
    
    private String confirmpassword;
	private String gender;

	private String shopname ;
	private String commerciallicensenumber;
	private String shopaddress;
	private String registrationnumber;
	
    private String mobilenumber;
    private String city;
    private String state;
    
    private String country;
   
    
    
	private String landmark;
	
	private String pincode;
	
	

    private Collection<? extends GrantedAuthority> authorities;

    public UserPrinciple(Long id, String firstname, String lastname,
			    		String username, String email, String password,String confirmpassword,String gender, String shopname ,String commerciallicensenumber,String shopaddress, 
			    		String registrationnumber ,String mobilenumber,String city,String state,String country,String landmark, String pincode,
			    	
			    		Collection<? extends GrantedAuthority> authorities) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.username = username;
        this.email = email;
        this.password = password;
        this.confirmpassword = confirmpassword;
        this.gender=gender;
        this.shopname=shopname;
        this.commerciallicensenumber=commerciallicensenumber;
        this.shopaddress=shopaddress;
        this.registrationnumber = registrationnumber;
        this.mobilenumber = mobilenumber;
        this.city = city;
        this.state = state;
        this.country = country;
       
        this.landmark=landmark;
        this.pincode = pincode;
       
        
        
        this.authorities = authorities;
    }

    public static UserPrinciple build(User user) {
        List<GrantedAuthority> authorities = user.getRoles().stream().map(role ->
                new SimpleGrantedAuthority(role.getName().name())
        ).collect(Collectors.toList());

        return new UserPrinciple(
                user.getId(),
                user.getFirstname(),
                user.getLastname(),
                user.getUsername(),
                user.getEmail(),
                user.getPassword(),
                user.getConfirmpassword(),
                user.getGender(),
                user.getShopname(),
                user.getCommerciallicensenumber(),
                user.getShopaddress(),
                user.getRegistrationnumber(),
                user.getMobilenumber(),
                user.getCity(),
                user.getState(),
                user.getCountry(),
              
                user.getLandmark(),
                user.getPincode(),
               
           
                authorities
        );
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return firstname;
    }
   
    public String getLastname() {
		return lastname;
	}



	public String getEmail() {
        return email;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public String getPassword() {
        return password;
    }
    
    public String getConfirmpassword() {
		return confirmpassword;
	}
    public String getGender() {
		return gender;
	}

	public String getShopname() {
		return shopname;
	}

	public String getCommerciallicensenumber() {
		return commerciallicensenumber;
	}

	public String getShopaddress() {
		return shopaddress;
	}

	public String getRegistrationnumber() {
		return registrationnumber;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getCountry() {
		return country;
	}

	public String getLandmark() {
		return landmark;
	}

	public String getPincode() {
		return pincode;
	}

	@Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        UserPrinciple user = (UserPrinciple) o;
        return Objects.equals(id, user.id);
    }
}