package abhibargain.jwtauthentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import abhibargain.jwtauthentication.model.User;

public interface UsersRepo extends JpaRepository<User, Long> {
	
	

}
