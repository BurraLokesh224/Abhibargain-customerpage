package abhibargain.jwtauthentication.security.services;

import java.util.Calendar;
import java.util.Random;


import org.springframework.stereotype.Service;
@Service
public class OtpService {
	
	
	public static int generateOTP1(){
		Random random = new Random();
		int otp = 1000 + random.nextInt(9000);
		
		
		
//	Calendar c=Calendar.getInstance();
//	long otpgentime=c.getTimeInMillis();
		//(System.currentTimeMillis()+500);
//		otpCache.put(key, otp);
		return otp;
		
		
		
		
	
		 }
}