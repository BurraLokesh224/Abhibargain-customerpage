package abhibargain.jwtauthentication.controller;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.Set;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

//import abhibargain.jwtauthentication.message.request.ForgetForm;
import abhibargain.jwtauthentication.message.request.LoginForm;
import abhibargain.jwtauthentication.message.request.OtpForm;
import abhibargain.jwtauthentication.message.request.ResetForm;
import abhibargain.jwtauthentication.message.request.SignUpForm;
import abhibargain.jwtauthentication.model.Role;
import abhibargain.jwtauthentication.model.RoleName;
import abhibargain.jwtauthentication.model.User;

import abhibargain.jwtauthentication.repository.RoleRepository;
import abhibargain.jwtauthentication.repository.UserRepository;
import abhibargain.jwtauthentication.security.jwt.JwtProvider;
import abhibargain.jwtauthentication.security.services.OtpService;

@Controller
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/auth")

public class AuthRestAPIs {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JwtProvider jwtProvider;

	@Autowired

	public JavaMailSender JavaMailSender;

	@Autowired
	public OtpService otpService;
	
	long otpgentime;

	int otp;


	

	@PostMapping("/singnup")
	public ResponseEntity<String> registerUser(@Valid @RequestBody SignUpForm signUpRequest) {
		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
			return new ResponseEntity<String>("Fail -> Username is already taken!", HttpStatus.BAD_REQUEST);
		}

		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			return new ResponseEntity<String>("Fail -> Email is already in use!", HttpStatus.BAD_REQUEST);
		}

		// Creating user's account
		User user = new User(signUpRequest.getFirstname(), signUpRequest.getLastname(), signUpRequest.getUsername(),
				signUpRequest.getEmail(), (signUpRequest.getPassword()), (signUpRequest.getConfirmpassword()),
				signUpRequest.getGender(), signUpRequest.getShopname(), signUpRequest.getCommerciallicensenumber(),
				signUpRequest.getShopaddress(), signUpRequest.getRegistrationnumber(), signUpRequest.getMobilenumber(),
				signUpRequest.getCity(), signUpRequest.getState(), signUpRequest.getCountry(),
				signUpRequest.getLandmark(), signUpRequest.getPincode());

		// Gender Selection Loop....
		if ("MALE".equals(signUpRequest.getGender())) {

		} else if ("FEMALE".equals(signUpRequest.getGender())) {

		} else if ("OTHERS".equals(signUpRequest.getGender())) {

	  	} else {
			new RuntimeException("Fail! -> Cause: Invalid Gender.");
			return ResponseEntity.ok().body("Invalid Gender");
		}

		Set<String> strRoles = signUpRequest.getRole();
		Set<Role> roles = new HashSet<>();

		strRoles.forEach(role -> {
			switch (role) {
			case "admin":
				Role adminRole = roleRepository.findByName(RoleName.ROLE_ADMIN)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(adminRole);

				break;

			case "pm":
				Role pmRole = roleRepository.findByName(RoleName.ROLE_PM)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(pmRole);

				break;

			default:
				Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(userRole);
			}
		});

		user.setRoles(roles);
		userRepository.save(user);

		return ResponseEntity.ok().body("User registered successfully!");
	}

	
	
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginForm loginRequest) {

		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);

		String jwt = jwtProvider.generateJwtToken(authentication);

		return new ResponseEntity<String>(" Username exist", HttpStatus.FOUND);
	}

	@PostMapping("/reset")
	public ResponseEntity<String> registerUser(@Valid @RequestBody ResetForm resetRequest) {
		SimpleMailMessage message = new SimpleMailMessage();
		if (userRepository.existsByEmail(resetRequest.getEmail())) {

			message.setTo(resetRequest.getEmail());
			message.setSubject("spring boot application");
			otp = otpService.generateOTP1();
			Calendar c = Calendar.getInstance();
			otpgentime = c.getTimeInMillis();

			message.setText("your otp is =" + otp);

			JavaMailSender.send(message);

			return new ResponseEntity<String>(" Mail ID exist", HttpStatus.FOUND);
		}
		return ResponseEntity.ok().body("email  ID doesnot Exist");

	}
	

	@PostMapping("/forgetotp")
	public ResponseEntity<String> registerUser1(@Valid @RequestBody OtpForm otpform) {
		Calendar c = Calendar.getInstance();

		Time time;
		if ((otp) == otpform.getOtp()) {

			if (c.getTimeInMillis() - otpgentime <= (5000 * 60)) {
				return new ResponseEntity<String>("entered otp is valid: ", HttpStatus.FOUND);
			}
			// HttpServlet.setStatus(HttpServletResponse.SC_OK);

			// HttpServlet.sendRedirect("/login");

		}

		return ResponseEntity.ok().body("enterd otp id invalid");

	}
	
	@RequestMapping("/email")
	public void sendMail() {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo("revathik.be@gmail.com");
		message.setSubject("spring boot application");
		int otp = OtpService.generateOTP1();

		message.setText("your otp is =" + otp);

		JavaMailSender.send(message);

	}
	

	@PutMapping("/hello/{email}")
	public ResponseEntity<String> updatehello(@PathVariable("email") String email, @RequestBody SignUpForm sf) {

		// System.out.println("update customer with id=");
		Optional<User> c = userRepository.findByEmail(email);
		if (c.isPresent()) {
			User u = c.get();
			u.setPassword(sf.getPassword());
			u.setConfirmpassword(sf.getConfirmpassword());

			userRepository.save(u);

			return ResponseEntity.ok().body("new password is created successfully");
		}
		// return new ResponseEntity<String>( HttpStatus.FOUND);
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);

	}

	

	//===========simple Email  ================
		/*@PostMapping("/email1")
		public void sendMail(@RequestBody Email email) {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setTo(email.getTo());
			message.setSubject(email.getMessageSubject());
			message.setText(email.getMessagebody());
			JavaMailSender.send(message);

		}*/

	/*	@PostMapping("/sendmailattachement")
		public String sendemailattachement(@RequestBody ResetForm email) throws MessagingException {

			MimeMessage message = JavaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setTo(email.getTo());
			helper.setSubject(email.getMessageSubject());
			helper.setText(email.getMessagebody());

			ClassPathResource path = new ClassPathResource("download.png");

			helper.addAttachment("download.png", path);
			JavaMailSender.send(message);
			return "successfully sent";

		}*/


	
	/*@GetMapping(path = "/card")
	public ResponseEntity<Map<String, String>> registerUser1(@RequestParam("id") Long id) {
		Map<String, String> map = new HashMap<String, String>();
		User u = user.findById(id);

		map.put("firstName", u.getFirstname());
		map.put("LastName", u.getLastname());
		map.put("RandomAccess", this.getRandomNumber());
		map.put("cvv", this.getRandomCvv());
		map.put("Date", this.getExpiryDate());
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
	}

	@PutMapping(path = "/cardDetails/{id}")
	public ResponseEntity<User> save(@PathVariable Long id) {
		User userObj = user.findById(id);
		userObj.setRandomAccess(this.getRandomNumber());
		userObj.setCvv(this.getRandomNumber());
		userObj.setExpiryDate(this.getExpiryDate());
		User us=user.save(userObj);
		return new ResponseEntity<User>(us, HttpStatus.OK);
	}
	
	public String getRandomNumber() {
		Random rand = new Random();
		long random = (long) (rand.nextDouble() * 10000000000000000L);
		StringBuilder str = new StringBuilder(String.valueOf(random));
		return str.insert(4, "-").insert(9, "-").insert(14, "-").toString();
	}

	public String getRandomCvv() {
		Random random = new Random();
		int cvv = random.nextInt(900) + 100;
		return String.valueOf(cvv);

	}

	public String getExpiryDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.YEAR, 5);
		Date oneYearFromNow = calendar.getTime();
		SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy");
		return fmt.format(oneYearFromNow);
	}*/
}