package abhibargain.jwtauthentication.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.NaturalId;
import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name = "Merchant", uniqueConstraints = { @UniqueConstraint(columnNames = { "username" }),
		@UniqueConstraint(columnNames = { "email" }), @UniqueConstraint(columnNames= {"mobilenumber"}) })
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank
	@Size(min = 3, max = 50)
	private String firstname;

	@NotBlank
	@Size(min = 3, max = 50)
	private String lastname;

	@NotBlank
	@Size(min = 3, max = 50)
	private String username;

	@NaturalId
	@NotBlank
	@Size(max = 50)
	@Email
	private String email;

	@NotBlank
	@Size(min = 6, max = 100)
	private String password;

	@NotBlank
	@Size(min = 6, max = 100)
	private String confirmpassword;

	@NotBlank
	//@Enumerated(EnumType.STRING)
	private String gender;

		
	@NotBlank
	@Size(min = 6, max = 100)
	private String shopname ;
	
	@NotBlank
	@Size(min = 6, max = 100)
	private String commerciallicensenumber;


	
	@NotBlank
	@Size(min = 6, max = 100)
	private String  shopaddress;
@NotBlank
	
	@Size(min = 6, max = 100)
	private String registrationnumber;
	
	

	@NotBlank
	@Size(min = 10, max = 10)
	private String mobilenumber;
	
	@NotBlank
	@Size(min = 6, max = 100)
	private String city;
	@NotBlank
	@Size(min = 6, max = 100)
	private String state;

	@NotBlank
	@Size(min = 6, max = 100)
	private String country;

	

	@NotBlank
	@Size(min = 6, max = 100)
	private String landmark;
	
	@NotBlank
	@Size(min = 6, max = 100)
	private String pincode;
	
	
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "user_roles", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<Role> roles = new HashSet<>();

	public User() {
	}

	

	public User(String firstname, String lastname, String username, String email, String password, String confirmpassword,
			String gender, String shopname,String commerciallicensenumber, String  shopaddress,String registrationnumber,String mobilenumber, String city, String state,String country, 
			 String landmark, String pincode) {
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.email = email;
		this.password = password;
		this.confirmpassword = confirmpassword;
		this.gender = gender;
		this.shopname =shopname ;
		this.commerciallicensenumber = commerciallicensenumber;
		this.shopaddress = shopaddress;
		this.registrationnumber = registrationnumber;
		this.mobilenumber = mobilenumber;
		this.city = city;
		this.state = state;
		this.country = country;
		this.landmark = landmark;
		this.pincode = pincode;
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	
	

	
	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public String getShopname() {
		return shopname;
	}

	public void setShopname(String shopname) {
		this.shopname = shopname;
	}

	public String getCommerciallicensenumber() {
		return commerciallicensenumber;
	}

	public void setCommerciallicensenumber(String commerciallicensenumber) {
		this.commerciallicensenumber = commerciallicensenumber;
	}

	public String getShopaddress() {
		return shopaddress;
	}

	public void setShopaddress(String shopaddress) {
		this.shopaddress = shopaddress;
	}

	public String getRegistrationnumber() {
		return registrationnumber;
	}

	public void setRegistrationnumber(String registrationnumber) {
		this.registrationnumber = registrationnumber;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLandmark() {
		return landmark;
	}

		public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

}
