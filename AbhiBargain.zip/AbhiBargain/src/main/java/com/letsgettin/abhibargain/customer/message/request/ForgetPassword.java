package com.letsgettin.abhibargain.customer.message.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import com.letsgettin.abhibargain.customer.model.User;

public class ForgetPassword {

	@NotBlank
	@Email
	private String email;	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
		
	
	
}
