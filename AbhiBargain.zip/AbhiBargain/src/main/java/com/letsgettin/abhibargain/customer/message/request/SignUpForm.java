package com.letsgettin.abhibargain.customer.message.request;

import java.util.Set;

import javax.validation.constraints.*;

public class SignUpForm {
   
    private String firstname;
    
   
    private String lastname;

    
    private String username;

   
    private String email;
    
    private Set<String> role;
    
   
    private String password;
    
 
    private String confirmpassword;
    
  
	private String gender;

	
	private String Idproof;

 
    private String phonenumber;
    

	private String country;

	
	private String state;

	
	private String city;
	

	private String occupation;

	
	private String address;

	
	private String landmark;
	
	
	private String pincode;
	
	
	private String family;



 

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getConfirmpassword() {
		return confirmpassword;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIdproof() {
		return Idproof;
	}

	public void setIdproof(String idproof) {
		this.Idproof = idproof;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public String getPhonenumber() {
		return phonenumber;
	}
	

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
		
		
	}
	
	
	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public Set<String> getRole() {
    	return this.role;
    }
    
    public void setRole(Set<String> role) {
    	this.role = role;
    }
    

	

	
}