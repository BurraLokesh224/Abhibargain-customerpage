package com.letsgettin.abhibargain.customer.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.letsgettin.abhibargain.customer.model.User;

import com.letsgettin.abhibargain.customer.repository.UserRepository;
import com.letsgettin.abhibargain.customer.security.jwt.JwtProvider;

@RestController
@RequestMapping("/api/loki")
public class CardGenerationController {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	JwtProvider jwtProvider;

	@Autowired
	UserRepository userRepository;

	/*
	 * @GetMapping(path = "/card", produces = "application/json")
	 * 
	 * public ResponseEntity<Map<String, String>>
	 * registeruser(@Valid @RequestParam("id") long id) {
	 * 
	 *  Date date = new Date(); 
	 * Map<String, String> map = new HashMap<String,String>(); 
	 * User usr = userRepository.findById(id);                
	 *  map.put("firstname",usr.getFirstname()); 
	 *  map.put("lastname", usr.getLastname());
	 * map.put("Randomnumber", this.GetRanadomdigit()); 
	 * map.put("cvv",this.randomCvv());
	 
	 *  map.put("currentdate", date.toString()); 
	 * map.put("expirydate", this.expirydate());
	 * 
	 * return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK); }
	 */
	@PutMapping(path = "carddetails/{id}")
	public ResponseEntity<String> cardnumber(@PathVariable("id") long id) {

		try {
			User usr1 = userRepository.findById(id);
			usr1.setRandomaccess(this.GetRanadomdigit());
			usr1.setCvv(this.randomCvv());
			usr1.setExpirydate(this.expirydate());

			userRepository.save(usr1);
			return ResponseEntity.ok().body("User cardnumber created successfully!");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok().body("User exception");
	}

	public String GetRanadomdigit() {
		Random rands = new Random();

		long ran = (long) (rands.nextDouble() * 10000000000000000L);
		StringBuilder builder = new StringBuilder(String.valueOf(ran));
		return builder.insert(4, " ").insert(9, " ").insert(14, " ").toString();

	}

	public String randomCvv() {
		Random rands = new Random();
		int cvv = (rands.nextInt(900) + 100);
		return String.valueOf(cvv);
	}

	public String expirydate() {

		Calendar calendar = Calendar.getInstance();
		// calendar.clear();
		calendar.add(Calendar.YEAR, 5);
		Date date = calendar.getTime();

		SimpleDateFormat smdf = new SimpleDateFormat("MM/YY");
		return smdf.format(date);

	}

}
