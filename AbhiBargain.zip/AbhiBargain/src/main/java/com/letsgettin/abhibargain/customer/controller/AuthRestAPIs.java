package com.letsgettin.abhibargain.customer.controller;

import java.util.Calendar;

import java.util.HashSet;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.letsgettin.abhibargain.customer.message.request.ForgetPassword;
import com.letsgettin.abhibargain.customer.message.request.LoginForm;
import com.letsgettin.abhibargain.customer.message.request.Otpsystem;
import com.letsgettin.abhibargain.customer.message.request.SignUpForm;

import com.letsgettin.abhibargain.customer.model.User;
import com.letsgettin.abhibargain.customer.repository.UserRepository;
import com.letsgettin.abhibargain.customer.security.jwt.JwtProvider;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/auth")
public class AuthRestAPIs {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JwtProvider jwtProvider;

	@Autowired
	public JavaMailSender JavaMailSender;

	int otp;

	long otpgenTime;

	@PostMapping("/signup")
	public ResponseEntity<String> registerUser(@Valid @RequestBody SignUpForm signUpRequest) {

		try {
			if (userRepository.existsByUsername(signUpRequest.getUsername())) {
				return new ResponseEntity<String>("Fail -> Username is already taken!", HttpStatus.BAD_REQUEST);
			}

			if (userRepository.existsByEmail(signUpRequest.getEmail())) {
				return new ResponseEntity<String>("Fail -> Email is already in use!", HttpStatus.BAD_REQUEST);
			}

			// Creating user's account
			User user = new User(signUpRequest.getFirstname(), signUpRequest.getLastname(), signUpRequest.getUsername(),
					signUpRequest.getEmail(), (signUpRequest.getPassword()), (signUpRequest.getConfirmpassword()),
					signUpRequest.getGender(), signUpRequest.getIdproof(), signUpRequest.getPhonenumber(),
					signUpRequest.getCountry(), signUpRequest.getState(), signUpRequest.getCity(),
					signUpRequest.getOccupation(), signUpRequest.getAddress(), signUpRequest.getLandmark(),
					signUpRequest.getPincode(), signUpRequest.getFamily());

			// Gender Selection Loop....
			if ("MALE".equalsIgnoreCase(signUpRequest.getGender())) {

			} else if ("FEMALE".equalsIgnoreCase(signUpRequest.getGender())) {

			} else if ("OTHERS".equalsIgnoreCase(signUpRequest.getGender())) {

			} else {
				new RuntimeException("Fail! -> Cause: Invalid Gender.");
				return ResponseEntity.ok().body("Invalid Gender");
			}

			// Occupation Selection Loop.......

			if ("POSTGRADUATE".equalsIgnoreCase(signUpRequest.getOccupation())) {

			} else if ("GRADUATE".equalsIgnoreCase(signUpRequest.getOccupation())) {

			} else {
				// new RuntimeException("Fail! -> Cause: Invalid Occupation.");
				return ResponseEntity.ok().body("Invalid Occupation");
			}

			userRepository.save(user);

		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.ok().body("User registation Exception");
		}
		return ResponseEntity.ok().body("User registered successfully!");
	}

	// -------------signin form----------------------
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginForm loginRequest) {
		try {

			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

			SecurityContextHolder.getContext().setAuthentication(authentication);

			String jwt = jwtProvider.generateJwtToken(authentication);
		} catch (Exception e) {
			e.printStackTrace();

			return ResponseEntity.ok().body("User signin Exception");

		}
		return ResponseEntity.ok("User login successfully");

	}

	@PostMapping("/forgetpassword")
	public ResponseEntity<String> registerUser(@Valid @RequestBody ForgetPassword resetRequest) {

		try {
			SimpleMailMessage message = new SimpleMailMessage();
			if (userRepository.existsByEmail(resetRequest.getEmail())) {
				message.setTo(resetRequest.getEmail());
				message.setSubject("simple mail seder ");
				message.setText(
						"hi how are you lokesh burra this is for check mail ... we u have successfully got reset password link ,click the below link and reset");
				otp = this.generateotp();
				Calendar cl = Calendar.getInstance();
				otpgenTime = cl.getTimeInMillis();

				message.setText(" otp send to your email account = " + otp);
				// message.setText("https://www.javatpoint.com/spring-mvc-tutorial");

				JavaMailSender.send(message);

				return new ResponseEntity<String>(
						"email exist successfully.....  we send reset password to your email id", HttpStatus.FOUND);
			}
			return ResponseEntity.ok().body("Invalid email does not exist, Please provide correct email");
		} catch (Exception e) {
			e.printStackTrace();

		}
		return ResponseEntity.ok().body("User Forgetpassword Exception!");
	}

	@PostMapping("/otpcampar")
	public ResponseEntity<String> otpvalidate(@Valid @RequestBody Otpsystem otpsystem) {
		try {
			Calendar cl = Calendar.getInstance();
			if ((otp) == otpsystem.getOtp()) {
				if (cl.getTimeInMillis() - otpgenTime <= (500000)) {
					return new ResponseEntity<String>(" otp validation successfully", HttpStatus.FOUND);

				}
			}
			return ResponseEntity.ok().body("User otp invalid !");
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.ok().body("Otp comparation Exception");
		}
	}

	@PutMapping("/customers/{email}")
	public ResponseEntity<String> resetpassword(@PathVariable("email") String email,
			@RequestBody SignUpForm resetpassword) {
		try {
			System.out.println("Update Customer with ID = " + email + "...");

			Optional<User> customerData = userRepository.findByEmail(email);

			if (customerData.isPresent()) {
				User customer = customerData.get();
				customer.setPassword(encoder.encode(resetpassword.getPassword()));
				customer.setConfirmpassword(encoder.encode(resetpassword.getConfirmpassword()));

				userRepository.save(customer);

				return ResponseEntity.ok().body("your new password created successfully!");
			}
			return new ResponseEntity<>("something went wrong", HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			e.printStackTrace();

		}
		return ResponseEntity.ok().body("reset password Exception!");

	}

	@PutMapping("/updateprofile/{email}")
	public ResponseEntity<String> editcustomerdetails(@PathVariable("email") String email,
			@RequestBody SignUpForm editprofile) {
		try {
			System.out.println("Update Customer with ID = " + email + "...");

			Optional<User> customerData = userRepository.findByEmail(email);

			if (customerData.isPresent()) {
				User customer = customerData.get();
				customer.setFirstname(editprofile.getFirstname());
				customer.setLastname(editprofile.getLastname());
				customer.setUsername(editprofile.getUsername());
				/*
				 * customer.setPassword(editprofile.getPassword());
				 * customer.setConfirmpassword(encoder.encode(editprofile.getConfirmpassword()))
				 * ;
				 */
				customer.setGender(editprofile.getGender());
				customer.setIdproof(editprofile.getIdproof());
				customer.setPhonenumber(editprofile.getPhonenumber());
				customer.setCountry(editprofile.getCountry());
				customer.setState(editprofile.getState());
				customer.setCity(editprofile.getCity());
				customer.setOccupation(editprofile.getOccupation());
				customer.setLandmark(editprofile.getLandmark());
				customer.setFamily(editprofile.getFamily());
				userRepository.save(customer);

				return ResponseEntity.ok().body("your profile edited successfully!");
			}
			return new ResponseEntity<>("something went wrong", HttpStatus.NOT_FOUND);

		} catch (Exception e) {
			e.printStackTrace();

		}
		return ResponseEntity.ok().body("User updateprofile Exception");

	}

	public int generateotp() {
		Random rm = new Random();
		int otp = 1000 + rm.nextInt(9999);
		return otp;
	}

}
