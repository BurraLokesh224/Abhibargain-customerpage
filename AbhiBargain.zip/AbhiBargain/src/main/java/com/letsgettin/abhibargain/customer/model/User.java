package com.letsgettin.abhibargain.customer.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.NaturalId;
import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name = "users_demo1")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String firstname;

	private String lastname;

	private String username;

	private String email;

	private String password;

	private String confirmpassword;

	private String gender;

	private String idproof;

	private String phonenumber;

	private String country;

	private String state;

	private String city;

	private String occupation;

	private String address;

	private String landmark;

	private String pincode;

	private String family;

	@Column(name = "randomaccess")
	private String randomaccess;
	@Column(name = "cvv")
	private String cvv;
	@Column(name = "expirydate")
	private String expirydate;

	// @ManyToMany(fetch = FetchType.LAZY)
	// @JoinTable(name = "user_roles", joinColumns = @JoinColumn(name = "user_id"),
	// inverseJoinColumns = @JoinColumn(name = "role_id"))
	// private Set<Role> roles = new HashSet<>();

	public User() {
	}

	/*
	 * public User(@NotBlank @Size(min = 3, max = 50) String firstname,
	 * 
	 * @NotBlank @Size(min = 3, max = 50) String lastname) { super(); this.firstname
	 * = firstname; this.lastname = lastname; }
	 */

	public User(String firstname, String lastname, String username, String email, String password,
			String confirmpassword, String gender, String idproof, String phonenumber, String country, String state,
			String city, String occupation, String address, String landmark, String pincode, String family) {
		this.firstname = firstname;
		this.lastname = lastname;

		this.username = username;
		this.email = email;
		this.password = password;
		this.confirmpassword = confirmpassword;
		this.gender = gender;
		this.idproof = idproof;
		this.phonenumber = phonenumber;
		this.country = country;
		this.state = state;
		this.city = city;
		this.occupation = occupation;
		this.address = address;
		this.landmark = landmark;
		this.pincode = pincode;
		this.family = family;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIdproof() {
		return idproof;
	}

	public void setIdproof(String idproof) {
		this.idproof = idproof;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public String getRandomaccess() {
		return randomaccess;
	}

	public void setRandomaccess(String randomaccess) {
		this.randomaccess = randomaccess;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getExpirydate() {
		return expirydate;
	}

	public void setExpirydate(String expirydate) {
		this.expirydate = expirydate;
	}

}