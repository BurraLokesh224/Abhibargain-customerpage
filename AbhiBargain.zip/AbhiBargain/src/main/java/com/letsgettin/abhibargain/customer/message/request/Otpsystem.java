package com.letsgettin.abhibargain.customer.message.request;

public class Otpsystem {
	private String email;

	private int otp;
	private Long expirytime;
	private String cardNumber;
	

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public Long getExpirytime() {
		return expirytime;
	}

	public void setExpirytime(Long expirytime) {
		this.expirytime = expirytime;
	}

	
}
