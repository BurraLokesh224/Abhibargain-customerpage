package com.letsgettin.abhibargain.customer.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.letsgettin.abhibargain.customer.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    Optional<User> findByPhonenumber(String phonenumber);
    User findById(long id);
  
    Boolean existsByUsername(String username);
    Boolean existsByEmail(String email);
}